#ifndef _MY1690_H__
#define _MY1690_H__                           

class my1690
{   
     public: 
          void play();
          void pause();
          void nextTrack();
          void previousTrack();
          void volunePlus();
          void voluneDown();
          void reset();
          void fastForward();
          void fastBackward();
          void playPause();
          void stop();
          void setVolume();
          void setEQ();
          void setLoopMode();
          void folderSwitch();
          void selectPlay();
          void playInFolder();
          void intercut();
          void intercutToFolder();
     private:
          
};

#endif
